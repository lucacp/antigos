/*
 * Implementação e avaliação de classificadores (J48-tree e SVM)
 * Lucas Parnoff, Rafael Ribeiro
 */

import java.text.DecimalFormat;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.LibSVM;
import weka.classifiers.trees.J48;
import weka.core.Debug.Random;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class Main {

	 public static void main(String[] args) throws Exception{
	     if(args.length != 1){
	    	 System.out.println("Deve-se passar o nome do arquivo .arff como parâmetro.");
	    	 System.exit(0);
	     }
		 DataSource saida = new DataSource(args[0]);
		 //DataSource saida = new DataSource("/home/rafael/saida.arff");
		 // Create an empty training set
         Instances iExample = saida.getDataSet();

         // Set class index
         iExample.setClassIndex(iExample.numAttributes() -1);

         //Classifier cModel = new J48();
         Classifier cModel = new LibSVM();
         cModel.buildClassifier(iExample);

         // Test the model
         Evaluation eTest = new Evaluation(iExample);
         Evaluation eVail = new Evaluation(iExample);
         eTest.evaluateModel(cModel, iExample);

         // Get the confusion matrix Directly
         Random rand = new Random(1);
         eVail.crossValidateModel(cModel,iExample,10,rand);

         // Print the result like the Weka explorer:
         System.out.println("\nDirectly:");

         double[][] cmMatrix = eTest.confusionMatrix();
         double sum = 0;
         for(int row_i=0; row_i<cmMatrix.length; row_i++){
             for(int col_i=0; col_i<cmMatrix.length; col_i++){
                 System.out.print(cmMatrix[row_i][col_i]);
                 sum += cmMatrix[row_i][col_i];
                 System.out.print("|");
             }
             System.out.println();
         }
         DecimalFormat df = new DecimalFormat("0.##");
         double accur = (cmMatrix[0][0]+cmMatrix[1][1])/sum*100;
         System.out.println("Accuracy: "+df.format(accur)+"%\n");

         // Print the Result of CrossValidation
         System.out.println("CrossValidation:");

         //System.out.println(eVail.toClassDetailsString());
         double[][] cm2Matrix = eVail.confusionMatrix();
         sum = 0;
         for(int row_i=0; row_i<cm2Matrix.length; row_i++){
             for(int col_i=0; col_i<cm2Matrix.length; col_i++){
                 System.out.print(cm2Matrix[row_i][col_i]);
                 sum += cm2Matrix[row_i][col_i];
                 System.out.print("|");
             }
             System.out.println();
         }
         accur = (cm2Matrix[0][0]+cm2Matrix[1][1])/sum*100;
         System.out.println("Accuracy: "+df.format(accur)+"%\n");

         //print another window to see the tree J48
         //System.out.println("\n"+cModel);
	}
}
