#!/usr/bin/env python3

# Formatação das entradas e geração do .arff
# Lucas Parnoff, Rafael Ribeiro

from collections import OrderedDict
import unicodedata

def remover_diacriticos(texto):
    s = unicodedata.normalize('NFD',texto)
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn')

def write_item(simbolos, resultado):
    for k in simbolos.keys():
        f.write(str(simbolos[k])+",")
    f.write(str(resultado)+"\n")

def contar(string, dsimbolos):
    s = remover_diacriticos(string[:-1].lower())
    for c in s:
        if c in dsimbolos:
            dsimbolos[c] += 1


f = open('sementes_treinamento.csv')

positivos = []
negativos = []

for line in f:
    s = line.split(',')
    if s[6] == '-1': # Coluna 'sumario' do csv
        negativos.append(s[5]) # Coluna 'texto' do csv
    else:
        positivos.append(s[5])

fp = open('positivos.txt','w')
for i in positivos:
    fp.write(i+'\n')

fn = open('negativos.txt','w')
for i in negativos:
    fn.write(i+'\n')

simbolos2 = set(['<', '(', '*', '–', '~', '/', '.', '+', '!', '>', ';', ':', '?', '[', '&', '=', '^', '#', '¬', '$', ')', ']', '@'])

for i in range(26):
    simbolos2.add(chr(ord('a')+i))

for i in range(10):
    simbolos2.add(chr(ord('0')+i))

simbolos = dict(zip(sorted(simbolos2), [0 for x in range(len(simbolos2))])) 

f = open("saida.arff","w")
f.write("@relation analisador_sentimentos\n")

for k in simbolos.keys():
    f.write("@attribute '"+k+"' numeric\n")

f.write("@attribute 'class' {-1, 1}\n@data\n")


fn = open('negativos.txt')
for s in fn:
    dsimbolos = simbolos.copy()
    contar(s,dsimbolos)
    write_item(dsimbolos, -1)

fp = open('positivos.txt')
for s in fp:
    dsimbolos = simbolos.copy()
    contar(s,dsimbolos)
    write_item(dsimbolos, 1)


