#include "lfa.h"

using namespace std;

int main(int nargs,char** args){
	int num,i,o,a;
	estado *vet;
	estado *vet2;
	char **tabela,*varia;
	varia= new char[LINHA];
	tabela = new char*[TAMANHO];
	cout << "num.variaveis: ";
	cin >> a;
	for(i=0;i<a;i++){
		cin >> varia[i*2];
	};
	cout <<"num.estados: ";
	cin >> num;
	vet= new estado[num+1];
	for(i=0;i<num*(a+1)+1;i++){
		tabela[i]=new char[LINHA];
	};
	for(i=0,o=0;i<num*(a+1);i++){
		cin >> tabela[i];
	};
	for(i=0,o=0;i<num*(a+1);i++){
		if(i%(a+1)==0){
			if(i>a)
				o++;
			vet[o].setEstado(tabela[i],a);
		}else
			vet[o].setTrans(tabela[i],(i%(a+1))-1);
	};
	int c;
	for(i=0;i<num;i++){
		for(c=0,o=0;o<LINHA-1&&c<a;o++){
			if(vet[i].t[c].var[o]==','&&(o-1)<2){
				vet[i].t[c].var[o]=vet[i].t[c].var[o-1];
				vet[i].t[c].var[o-1]='[';
			}
			else if(vet[i].t[c].var[o]=='\0'&&vet[i].t[c].var[0]=='['){
				vet[i].t[c].var[o]=']';
				c++;o=0;
			}
			else if(vet[i].t[c].var[0]=='-'||o>LINHA-3){
				o=0;c++;
			};
		};
	};
	for(i=0,o=0;i<num;i++,o++){
		cout << vet[o].getEstado()<<" | ";
		for(c=0;c<a;c++)
			cout << vet[o].getTrans(c)<<" | ";
		cout << "\n";
	};
	vet2=new estado[LINHA];
	int p;
	for(i=0,c=0,p=0;i<LINHA;i++,p=0,c=0){
		if(vet[i].t[c].var[0]!='-'&&i==0){
			vet2[i].setEstado(vet[i%(num+1)].t[c].var,a);
			cout <<"\nt"<< vet2[i].est<<" ";
		}
		else if(i>0){
				if(vet2[i-1].t[c].var[0]!='-'){
					vet2[i].setEstado(vet2[i-1].t[c].var,a);
					cout <<"\nta"<< vet2[i].est<<" ";
				};
		};
		for(o=0;o<int(strlen(vet2[i].est));o++){
			for(p=0;p<num;p++){
				if(vet2[i].est[o]==vet[p].est[0]&&strlen(vet2[i].t[c].var)>0&&vet[p].t[c].var[0]!='-'){
					strcat(vet2[i].t[c].var,vet[p].t[c].var);
					for(p=0;p<LINHA;p++){
						if((vet2[i].t[c].var[p]==']'&&vet2[i].t[c].var[p+1]=='[')||(vet2[i].t[c].var[p]==vet2[i].t[c].var[p+2])){
							int w=2;
							for(;(w+p-2)<LINHA;w++){
								vet2[i].t[c].var[p+w-2]=vet2[i].t[c].var[p+w];
							};
							
						};	
					};
					cout <<"t0a"<< vet2[i].t[c].var<<" ";
				}
				else if(vet2[i].est[o]==vet[p].est[0]&&vet[p].t[c].var[0]!='-'){
					strcpy(vet2[i].t[c].var,vet[p].t[c].var);
					cout <<"t1a"<< vet2[i].t[c].var<<" ";
				};
			};
		};
		c++;
		for(o=0;o<num;o++){
			for(p=0;p<num;p++){
				if(vet2[i].est[o]==vet[p].est[0]&&strlen(vet2[i].t[c].var)>0&&vet[p].t[c].var[0]!='-'){
					strcat(vet2[i].t[c].var,vet[p].t[c].var);
					for(p=0;p<LINHA;p++){
						if((vet2[i].t[c].var[p]==']'&&vet2[i].t[c].var[p+1]=='[')||(vet2[i].t[c].var[p]==vet2[i].t[c].var[p+2])){
							int w=2;
							for(;(w+p-2)<LINHA;w++){
								vet2[i].t[c].var[p+w-2]=vet2[i].t[c].var[p+w];
							};
							
						};	
					};
					cout <<"t2a"<< vet2[i].t[c].var<<" ";
				}
				else if(vet2[i].est[o]==vet[p].est[0]&&vet[p].t[c].var[0]!='-'){
					strcpy(vet2[i].t[c].var,vet[p].t[c].var);
					cout <<"t3a"<< vet2[i].t[c].var<<" ";
				};
			};
		};
	};
	return 0;
};
