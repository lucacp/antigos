#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <string>
#include <new>
#define LINHA 20

using namespace std;

struct transicao{
	string tra;
};

struct estado{
	string nome;
	int ntr;
	transicao *tr;
	int transtart(int i){
		tr= new transicao[i]();
		ntr=i;
		return 0;
	};
	void final(){
		delete[] tr;
	};
	string getString(){
		int i;
		string a;
		a=nome;
		a+="::=";
		for(i=0;i<ntr;i++){
			a+=tr[i].tra;
			a+="|";
		};
		return a;
	};
	string getStringFF(){
		int i;
		string a;
		a=nome;
		a+="| ";
		for(i=0;i<(int)tr->tra.length();i++){
			a+=tr->tra[i];
			a+="|";
		};
		return a;
	}
};
