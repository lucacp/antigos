#include "lfa.h"

bool checkTer(string a,string *str){
	size_t pos=0;
	if((pos=(*str).find(a[0]))!=(size_t)-1){
		//cout << "v ";
		return true;
	};
	//cout << "f ";
	return false;
	
};

void makeFirst(estado *f,estado *es,int ntr,string *term){
	string est;
	int i,t,p,au;//;
	size_t pos=0;
	for(i=0;i<ntr;i++){
		f[i].nome=es[i].nome;
		est+=es[i].nome;
		f[i].transtart(1);
	};
	bool mudanc=true,px=false;
	while(mudanc){
		mudanc=false;
		for(i=0;i<ntr;i++){
			for(t=0,au=0,px=false;t<es[i].ntr;t++){
				if(px){
					t--;
					au++;
					px=false;
				};
				if((f[i].tr->tra.find(es[i].tr[t].tra[au]))==(size_t)(-1)){
				//	cout<<i<<" "<<t<<"  ";
					if(checkTer(&es[i].tr[t].tra[au],term)){
						f[i].tr->tra+=es[i].tr[t].tra[au];
			//			cout << f[i].tr->tra<<"|\n";
						au=0;
						mudanc=true;
					}
					else{
						pos=est.find(es[i].tr[t].tra[au]);		
				//		cout<< pos<<" "<<es[i].tr[t].tra[au]<<endl;
						if(pos!=(size_t)(-1)){
							for(p=0;p<(int)f[pos].tr->tra.length();p++){
								if((f[i].tr->tra.find(f[pos].tr->tra[p]))==(size_t)(-1)){
									if((f[pos].tr->tra[p])!='?'){
										f[i].tr->tra+=f[pos].tr->tra[p];
					//					cout << f[pos].tr->tra[p]<<" i"<<i<<" t"<<t<<"  ";
										mudanc=true;
									}
									else{
						//				cout << "px ";
										px=true;
									}
									
							//		cout << f[i].tr->tra<<endl;
								};
							};
							if((f[pos].tr->tra.find('?'))!=(size_t)(-1)){
								px=true;
							}
						}
						else{
							au=0;
						};
					};
				}else
					au=0;
				
			};
		};
	};
}
/*
int checkNter(char a){
	int i;
	for(i=0;nter[i]!='\0'||i<50;i++){
		if(a==nter[i])
			return 1;
	};
	return 0;	
}*/

void makeFollow(estado *f,estado *es,estado *fir,int ntr,string *term){
	string est;
	int i,t,p,au,aux2,prox=1;
	size_t pos=0,post=0;//,po=0;
	for(i=0;i<ntr;i++){
		f[i].nome=es[i].nome;
		est+=es[i].nome;
		f[i].transtart(1);
	};
	f[0].tr->tra="$";
	bool mudanc=true,px=false,finale=false;
	while(mudanc){
		mudanc=false;
		for(i=0;i<ntr;i++){
			for(t=0;t<es[i].ntr;t++,prox=1){
				if(!finale){
					for(p=0,au=(int)es[i].tr[t].tra.length();p<au;p++){
						if(px){
							prox++;
							px=false;
	//						cout << "px-1 ";
						}else
							prox=1;
		//				cout <<"\n"<<i<<" "<<t<<"  "<<p<<"   ";
						if(!checkTer(&es[i].tr[t].tra[p],term)){
							pos=est.find(es[i].tr[t].tra[p]);
			//				cout <<pos<<" "<<es[i].tr[t].tra[p]<<endl;
							if((p+1)<au){
								if(pos!=(size_t)(-1)){
									if(checkTer(&es[i].tr[t].tra[p+prox],term)){
										if(f[pos].tr->tra.find(es[i].tr[t].tra[p+prox])==(size_t)(-1)){
											f[pos].tr->tra+=es[i].tr[t].tra[p+prox];
				//							cout <<"\n"<<es[i].tr[t].tra[p+prox]<<" + "<<f[pos].tr->tra<<"|1\n";
											mudanc=true;
											px=false;
										}
									}
									else{
										post=est.find(es[i].tr[t].tra[p+prox]);
					//					cout <<post<<" "<<es[i].tr[t].tra[p+prox]<<endl;
										if(post!=(size_t)(-1)){
											for(aux2=0;aux2<(int)fir[post].tr->tra.length();aux2++){
												if(f[pos].tr->tra.find(fir[post].tr->tra[aux2])==(size_t)(-1)){
													if((fir[post].tr->tra[aux2])!='?'){
														f[pos].tr->tra+=fir[post].tr->tra[aux2];
														mudanc=true;
						//								cout << " +_ ";
													}
													else{
							//							cout<< " -_ ";
														px=true;
														p--;
													}
								//					cout<<pos<<" "<< f[pos].tr->tra<<" |2\n";
												}
											}
										}
									}
								}
							}
						}
					}
				}
				else{
					for(p=-1,au=(int)es[i].tr[t].tra.length()-1;p<au;au--){
						if(!checkTer(&es[i].tr[t].tra[au],term)){
							pos=est.find(es[i].tr[t].tra[au]);
							if(pos!=(size_t)(-1)){
								for(aux2=0;aux2<(int)f[i].tr->tra.length();aux2++){
									if((f[pos].tr->tra.find(f[i].tr->tra[aux2]))==(size_t)(-1)){
										f[pos].tr->tra+=f[i].tr->tra[aux2];
										mudanc=true;
									}
								};
								
							};
							if((fir[pos].tr->tra.find('?'))==(size_t)(-1)){
								au=p;
							}			
						}else
							au=p;
					}
				}
			}
		}
		if((!mudanc)&&(!finale)){
			mudanc=true;
			finale=true;
		};
			
	}
}

int Start(){
	estado *es=NULL,*fir=NULL,*fol=NULL;
	FILE *term=NULL;
	if((term=fopen("lfa.dat","r"))==NULL)
		cout<<"erro de arquivo terminais"<<endl;
	string ar;
	string ter;
	string nter;
	//cout <<ar.capacity()<<" "<<ter.capacity()<<" "<<nter.capacity()<<endl;
	char character;
	int i,trans,a[LINHA],f,t,m;
	for(i=0;i<50;i++){
		fread(&character,sizeof(char),1,term);
		ter+=character;
	//	cout << ter.capacity()<<endl;
		if(ter[i]=='\0'){
			break;
		}
	};
	fclose(term);
	FILE *arq=NULL;
	if((arq=fopen("gram.dat","r"))==NULL){
		cout<<"arquivo de linguagem não encontrado";
		return 1;
	}
	for(i=0;i<LINHA;i++)
		a[i]=0;
	for(i=0,trans=0;feof(arq)==0;i++){
		fread(&character,sizeof(char),1,arq);
		if(character!='\n'&&character!=' '){
			ar+=character;
//			cout<<ar.capacity()<<endl;
			if(ar[i]=='='){
				trans++;
			}
			else if(ar[i]=='|')
				a[trans]++;
		}
		else
			i--;
	};	
	es=new estado[trans]();
	for(i=0;i<trans;i++){
		try{
			es[i].transtart(a[i+1]);
		}
		catch(bad_alloc& ba){
			cerr << "exception: "<<ba.what();
		};
	};
	//cout << ar.size()<<"\n"<<ar<<endl;
	for(i=2,f=0,t=0,m=-1;i<(int)ar.length() ;i++){
		if(ar[i]=='|'){
//			cout<<"|";
	//		cout << ar[f]<<endl;
			es[m].tr[t].tra=ar[f];
			f++;
			while(ar[f]!='|'){
		//		cout << ar[f]<<endl;
				es[m].tr[t].tra+=ar[f];
				f++;
			}
			t++;
			f=i+1;
		}	
		else if(ar[i]=='='){
			//cout <<"=";
			m++;
			t=0;
			//cout << ar[f]<<endl;
			es[m].nome+=ar[f];
			f=i+1;
		};
	};
	fir=new estado[trans]();
	fol=new estado[trans]();
	makeFirst(fir,es,trans,&ter);
	makeFollow(fol,es,fir,trans,&ter);
	for(i=0;i<trans;i++){
		cout <<"\n"<<es[i].getString();
		es[i].final();
	};
	cout<< "\nFirst: ";
	for(i=0;i<trans;i++){
		cout << "\n"<<fir[i].getStringFF();
		fir[i].final();
	};
	cout<< "\nFollow: ";
	for(i=0;i<trans;i++){
		cout << "\n"<<fol[i].getStringFF();
		fol[i].final();
	}
	
	cout <<"\n";
	fclose(arq);
	delete[] es;
	delete[] fir;
	delete[] fol;
	return 0;
}

int main(int nargs,char** args){
	Start();
	return 0;
};
