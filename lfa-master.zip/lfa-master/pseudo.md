while i != n
	write a state
	while j != m
		write the transition j of state i.


