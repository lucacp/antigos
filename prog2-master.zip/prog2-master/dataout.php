<?php
	mysqli_close($csql);
?>